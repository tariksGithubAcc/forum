<div class="conatiner-fluid bg-dark text-light">
    <p class="text-center">
        Copyright iDiscuss Coding Forums 2024 | All rights reserved
    </p>
</div>